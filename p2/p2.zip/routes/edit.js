// app.get('/:id/edit', requireLogin, (req, res) => {
//     // display edit form for contact with id = :id
//     // post to /:id/edit
//   });
  
//   app.post('/:id/edit', requireLogin, (req, res) => {
//     // edit contact logic
//     // redirect to /:id if successful
//     // display edit form with an error message if unsuccessful
//   });