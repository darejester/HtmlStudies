// app.get('/:id/delete', requireLogin, (req, res) => {
//     // display confirmation page for deletion
//     // have a form (no user input) that posts back to /:id/delete
//   });
  
//   app.post('/:id/delete', requireLogin, (req, res) => {
//     // delete contact logic
//     // redirect back to /
//   });