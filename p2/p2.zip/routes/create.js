const express = require('express')
const router = express.Router();

router.get('/', (req, res) => {
    // display create contact form
    // post to /create
    res.render('create');
  });
  
  // app.post('/', requireLogin, (req, res) => {
  //   // create contact logic
  //   // redirect to / if successful
  //   // display create contact form with an error message if unsuccessful
  // });

  module.exports = router;