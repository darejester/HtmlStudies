const express = require('express')
const router = express.Router();

router.get('/', (req, res) => {
    // display login form
    // post to /login
    // have a link to the /signup page
    console.log('login get');
    res.render('login');
  });
  
  router.post('/', (req, res) => {
    // login logic
    // redirect to / if successful
    // display login page with an error message if unsuccessful
    console.log('login post');
    res.render('index')
  });

  module.exports = router;