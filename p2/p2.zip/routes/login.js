app.get('/login', (req, res) => {
    // display login form
    // post to /login
    // have a link to the /signup page
  });
  
  app.post('/login', (req, res) => {
    // login logic
    // redirect to / if successful
    // display login page with an error message if unsuccessful
  });