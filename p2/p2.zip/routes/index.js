const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');

router.get('/', async (req, res) => {
  console.log('index get');
  // display all contacts in a table
  const allContacts = await req.db.getAllContacts();
  console.log(allContacts.length);
  
  res.render('index',{allContacts: allContacts});
});


router.post('/', async (req, res) => {
  console.log('index post');

  //console.log(req.body);
  //console.log(req.body.emailAddress);

  //if there is a new contact Id
  if(req.body.newContactId)
  {
    console.log("inside if");
    const contact = await req.db.findContact(req.body.newContactId);
    if (!contact) {
      res.writeHead(404);
      res.end();
      return;
    }
    //console.log(contact);
  
    await req.db.recordContact(contact,req.body);
  }

  //if there is a new user id
  if(req.body.newUserId)
  {
    console.log("inside if2");
    const user = await req.db.findUser(req.body.newUserId);

    const username = await req.db.findUserByUsername(req.body.username);
    if(username)
    {
      res.render('signup', {newUserId: req.body.newUserId, password: req.body.password, password2: req.body.password2, username: 0});
      return;
    }
    if(req.body.password != req.body.password2)
    {
      res.render('signup', {newUserId: req.body.newUserId, password: req.body.password, password2: req.body.password2, username: 1});
      return;
    }
    if (!user) {
      res.writeHead(404);
      res.end();
      return;
    }

    const salt = bcrypt.genSaltSync(10);
    const hash = bcrypt.hashSync(req.body.password, salt);
    console.log(salt);
    console.log(hash);
    const id = await req.db.recordUser(user,req.body,hash)
    req.session.user = await req.db.findUserById(id);
    //res.redirect('/');
    //console.log(req.db.getAllUsers());
 
    //await req.db.recordUser(user,req.body);
    
  }
  //if logged in
  if(req.body.loggedIn)
  {
    console.log("loggedIn");
  }

  const allContacts = await req.db.getAllContacts();
  //console.log(allContacts);

  res.render('index',{allContacts: allContacts});
});

router.get('/:id(\\d+)', async (req, res) => {
  console.log("index id get");

  console.log(req.params.id);
  const contact = await req.db.findContact(req.params.id);

  res.render('id',{contact: contact});
});

  module.exports = router;