const express = require('express')
const router = express.Router();

router.get('/', async (req, res) => {
  console.log('index get');
  // display all contacts in a table
  const allContacts = await req.db.getAllContacts();
  console.log(allContacts.length);

  // each row should be clickable to go to /:id
  // main page should have a link to login/logout and /create page to create new contact

  
  res.render('index',{allContacts: allContacts});
});


router.post('/', async (req, res) => {
  console.log('index post');

  //console.log(req.body);
  //console.log(req.body.emailAddress);

  const contact = await req.db.findContact(req.body.newContactId);
  if (!contact) {
    res.writeHead(404);
    res.end();
    return;
  }
  //console.log(contact);

  await req.db.recordContact(contact,req.body);
  // display all contacts in a table
  // each row should be clickable to go to /:id
  // main page should have a link to login/logout and /create page to create new contact
  
  const allContacts = await req.db.getAllContacts();
  //console.log(allContacts);

  res.render('index',{allContacts: allContacts});
});

// router.get('/:id', async (req, res) => {
//   console.log("index id get");
//   // display contact with id = :id
//   // have links to /:id/edit and /:id/delete
//   // have a link back to /
//   console.log(req.params.id);
//   const contact = await req.db.findContact(req.params.id);

//   res.render('id',{contact: contact});
// });

  module.exports = router;