app.get('/:id', requireLogin, (req, res) => {
    // display contact with id = :id
    // have links to /:id/edit and /:id/delete
    // have a link back to /
  });