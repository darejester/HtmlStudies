// const express = require('express')
// const router = express.Router();

// router.get('/:id', async (req, res) => {
//     console.log("id get");
//     // display contact with id = :id
//     // have links to /:id/edit and /:id/delete
//     // have a link back to /
//     const id = req.params.id;
//     console.log(id);

//     res.render('id', {contact:id});
//   });


//   module.exports = router;