const express = require('express')
const router = express.Router();

router.get('/', (req, res) => {
    // display signup form
    // post to /signup
    res.render('signup');
  });
  
  // app.post('/', (req, res) => {
  //   // signup logic
  //   // redirect to /login if successful
  //   // display signup page with an error message if unsuccessful
  // });

  module.exports = router;