app.get('/signup', (req, res) => {
    // display signup form
    // post to /signup
  });
  
  app.post('/signup', (req, res) => {
    // signup logic
    // redirect to /login if successful
    // display signup page with an error message if unsuccessful
  });