require('dotenv').config();
const Database = require('dbcmps369');

class ContactDB {
    constructor() {
        this.db = new Database();
    }

    async initialize() {
        await this.db.connect();

        await this.db.schema('Contact', [
            { name: 'id', type: 'INTEGER' },
            { name: 'firstName', type: 'TEXT' },
            { name: 'lastName', type: 'TEXT' },
            { name: 'phoneNumber', type: 'TEXT' },
            { name: 'emailAddress', type: 'TEXT' },
            { name: 'street', type: 'TEXT' },
            { name: 'city', type: 'TEXT' },
            { name: 'state', type: 'TEXT' },
            { name: 'zip', type: 'TEXT' },
            { name: 'country', type: 'TEXT' },
            { name: 'contactByPhone', type: 'INTEGER' },
            { name: 'contactByEmail', type: 'INTEGER' }
        ], 'id');

        await this.db.schema('Users', [
            { name: 'id', type: 'INTEGER' },
            { name: 'firstName', type: 'TEXT' },
            { name: 'lastName', type: 'TEXT' },
            { name: 'username', type: 'TEXT' },
            { name: 'password', type: 'INTEGER' }
        ], 'id');

        const incomplete = await this.db.read('Contact', [{ column: 'firstName', value: "" }]);
        for (const c of incomplete) {
            await this.db.delete('Contact', [{ column: 'id', value: c.id }]);
            await this.db.delete('Users', [{ column: 'id', value: c.id }]);
        }
    }

    async createContact() {
        console.log("createContact");
        const id = await this.db.create('Contact', [
            //id is = to Users.length
            { column: 'firstName', value: "" },
            { column: 'lastName', value: "" },
            { column: 'phoneNumber',value: ""  },
            { column: 'emailAddress', value: ""  },
            { column: 'street', value: ""  },
            { column: 'city', value: ""  },
            { column: 'state', value: ""  },
            { column: 'zip',value: ""  },
            { column: 'country', value: ""  },
            { column: 'contactByPhone', value: 0 },
            { column: 'contactByEmail', value: 0 }
        ])
        return id;
    }

    async getAllContacts() {
        console.log("getAllContacts");
        const contacts = await this.db.read('Contact',[]);
        
        console.log(contacts);
        return contacts;
    }

     async recordContact(contact,newContact) {
        console.log("Record Contact");
        console.log(newContact);
        await this.db.update('Contact',
        [
            { column: 'firstName', value: newContact.firstName },
            { column: 'lastName', value: newContact.lastName },
            { column: 'phoneNumber', value: newContact.phoneNumber },
            { column: 'emailAddress', value: newContact.emailAddress },
            { column: 'street', value: newContact.street },
            { column: 'city', value: newContact.city },
            { column: 'state', value: newContact.state },
            { column: 'zip', value: newContact.zip },
            { column: 'country', value: newContact.country },
            { column: 'contactByPhone', value: newContact.contactByPhone },
            { column: 'contactByEmail', value: newContact.contactByEmail }
        ],
        [
            { column: 'id', value: contact.id }
        ]
        );
    }

    async findContact(id) {
        const contact = await this.db.read('Contact', [{ column: 'id', value: id }]);
        console.log("findContact");
        //console.log(contact[0]);
        if (contact.length > 0) return contact[0];
        else {
            return undefined;
        }
    }








    async findUserByEmail(email) {
        const us = await this.db.read('Users', [{ column: 'email', value: email }]);
        if (us.length > 0) return us[0];
        else {
            return undefined;
        }
    }

    async findUserById(id) {
        const us = await this.db.read('Users', [{ column: 'id', value: id }]);
        if (us.length > 0) return us[0];
        else {
            return undefined;
        }
    }

   

    async complete(game) {
        await this.db.update('Game',
            [{ column: 'complete', value: true }],
            [{ column: 'id', value: game.id }]
        );
    }

    async findGuesses(gameId) {
        const game_guesses = await this.db.read('Guess', [{ column: 'gameId', value: gameId }]);
        return game_guesses;
    }
}

module.exports = ContactDB;